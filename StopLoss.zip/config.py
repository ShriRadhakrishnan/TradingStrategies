ENDPOINT = 'https://paper-api.alpaca.markets/v2'
API_KEY = 'PKDBO80VLWZSXAVDJPHX'
SECRET_KEY = '7tt6P3kcvkMQ8aFsurUSLebNm0QEpPCVQbzewoMu'